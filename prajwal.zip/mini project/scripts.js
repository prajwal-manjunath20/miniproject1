// Countdown Timer for the main event
const countdownDate = new Date("March 25, 2025 00:00:00").getTime(); // Set the event date

// Update the countdown every 1 second
const countdownFunction = setInterval(function() {
    const now = new Date().getTime(); // Get the current time
    const distance = countdownDate - now; // Calculate the time remaining

    // Time calculations for days, hours, minutes, and seconds
    const days = Math.floor(distance / (1000 * 60 * 60 * 24)); // Calculate the number of days
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)); // Calculate hours
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)); // Calculate minutes
    const seconds = Math.floor((distance % (1000 * 60)) / 1000); // Calculate seconds

    // Display the result in the countdown timer element
    document.getElementById("countdown-timer").innerHTML = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    // If the countdown is finished, display a message
    if (distance < 0) {
        clearInterval(countdownFunction); // Stop the countdown
        document.getElementById("countdown-timer").innerHTML = "The event has started! 🎉";
    }
}, 1000);

// Handling the registration form submission
document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting and refreshing the page

    // Get the form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const eventSelection = document.getElementById('event').value;

    // Display the registration success message
    const message = `🎉 Thank you, ${name}! You have successfully registered for the ${eventSelection} event. A confirmation email has been sent to ${email}. 🎉`;
    document.getElementById('registration-message').textContent = message;

    // Optionally, reset the form after successful submission
    document.getElementById('registration-form').reset();
});
